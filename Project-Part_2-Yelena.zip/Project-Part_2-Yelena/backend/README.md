# Backend – Project Part 2 (Disneyland Paris)

This si the second part of the WEB project. This part and the first one are on the same theme : Disneyland Paris !

## Structure

- `data/items.js`
- `server.js` 
- `package.json` 
- `.gitignore` 

## Installation (on Mac)

1. Go to the backend folder:

   ```bash
   cd backend
   npm install